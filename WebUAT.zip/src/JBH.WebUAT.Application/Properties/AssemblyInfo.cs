﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("JBH.WebUAT.Application.Tests")]
