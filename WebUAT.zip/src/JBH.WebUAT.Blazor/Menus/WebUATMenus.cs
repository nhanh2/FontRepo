﻿namespace JBH.WebUAT.Blazor.Menus;

public class WebUATMenus
{
    private const string Prefix = "WebUAT";
    public const string Home = Prefix + ".Home";

    //Add your menu items here...

}
