﻿namespace JBH.WebUAT.Blazor.Pages;

public partial class Index
{

}
