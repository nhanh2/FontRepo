﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("JBH.WebUAT.EntityFrameworkCore.Tests")]
