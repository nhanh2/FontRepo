﻿namespace JBH.WebUAT.Permissions;

public static class WebUATPermissions
{
    public const string GroupName = "WebUAT";

    //Add your own permission names. Example:
    //public const string MyPermission1 = GroupName + ".MyPermission1";
}
