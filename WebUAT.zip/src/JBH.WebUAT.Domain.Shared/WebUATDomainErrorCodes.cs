﻿namespace JBH.WebUAT;

public static class WebUATDomainErrorCodes
{
    /* You can add your business exception error codes here, as constants */
}
