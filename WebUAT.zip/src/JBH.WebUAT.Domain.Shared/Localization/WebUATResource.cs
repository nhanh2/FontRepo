﻿using Volo.Abp.Localization;

namespace JBH.WebUAT.Localization;

[LocalizationResourceName("WebUAT")]
public class WebUATResource
{

}
