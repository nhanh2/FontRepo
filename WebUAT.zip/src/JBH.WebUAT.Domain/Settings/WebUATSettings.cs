﻿namespace JBH.WebUAT.Settings;

public static class WebUATSettings
{
    private const string Prefix = "WebUAT";

    //Add your own setting names here. Example:
    //public const string MySetting1 = Prefix + ".MySetting1";
}
