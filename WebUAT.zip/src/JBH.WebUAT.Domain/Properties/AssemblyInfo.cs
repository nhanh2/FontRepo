﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("JBH.WebUAT.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("JBH.WebUAT.TestBase")]
