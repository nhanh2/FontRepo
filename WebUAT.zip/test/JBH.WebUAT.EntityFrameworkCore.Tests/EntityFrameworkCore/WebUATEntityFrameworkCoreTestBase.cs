﻿using Volo.Abp;

namespace JBH.WebUAT.EntityFrameworkCore;

public abstract class WebUATEntityFrameworkCoreTestBase : WebUATTestBase<WebUATEntityFrameworkCoreTestModule>
{

}
