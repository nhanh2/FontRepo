﻿namespace JBH.WebUAT;

public abstract class WebUATApplicationTestBase : WebUATTestBase<WebUATApplicationTestModule>
{

}
