﻿namespace JBH.WebUAT;

public abstract class WebUATDomainTestBase : WebUATTestBase<WebUATDomainTestModule>
{

}
