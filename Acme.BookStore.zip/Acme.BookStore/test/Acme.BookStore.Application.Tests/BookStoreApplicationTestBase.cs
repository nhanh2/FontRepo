﻿namespace Acme.BookStore;

public abstract class BookStoreApplicationTestBase : BookStoreTestBase<BookStoreApplicationTestModule>
{

}
