﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Acme.BookStore.Application.Tests")]
