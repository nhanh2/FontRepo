﻿namespace Acme.BookStore.Blazor.Menus;

public class BookStoreMenus
{
    private const string Prefix = "BookStore";
    public const string Home = Prefix + ".Home";

    //Add your menu items here...

}
