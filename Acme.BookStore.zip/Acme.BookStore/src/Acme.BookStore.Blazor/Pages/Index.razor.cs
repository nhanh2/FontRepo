﻿namespace Acme.BookStore.Blazor.Pages;

public partial class Index
{

}
