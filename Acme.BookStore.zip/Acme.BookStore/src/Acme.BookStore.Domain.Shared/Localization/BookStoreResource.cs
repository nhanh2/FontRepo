﻿using Volo.Abp.Localization;

namespace Acme.BookStore.Localization;

[LocalizationResourceName("BookStore")]
public class BookStoreResource
{

}
